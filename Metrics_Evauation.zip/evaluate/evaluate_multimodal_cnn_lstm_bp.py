import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score
)
import json
import matplotlib.pyplot as plt
import seaborn as sns

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.multimodal_cnn_lstm_bp import MultimodalCNNLSTM_BP

# ---------------- CONFIG ---------------- #
SEQ_LEN = 15
BATCH_SIZE = 16
STAGE_LABELS = ["W", "N1", "N2", "N3", "REM"]
SAVE_DIR = "data/processed/BANDPOWER"
MODEL_PATH = "multimodal_cnn_lstm_bp_best.pth"
OUT_PREFIX = "multimodal_cnn_lstm_bp"
# ---------------------------------------- #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD TEST DATA ---------------- #
X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
bandpower = np.load(f"{SAVE_DIR}/bandpower_test.npy")
y_test = np.load(f"{SAVE_DIR}/y_test.npy")

test_dataset = MultimodalSequenceDataset(
    X_eeg,
    X_eog,
    bandpower,
    y_test,
    seq_len=SEQ_LEN
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ---------------- LOAD MODEL ---------------- #
model = MultimodalCNNLSTM_BP(num_classes=5, hidden_size=128).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

# ---------------- INFERENCE ---------------- #
all_preds = []
all_labels = []

with torch.no_grad():
    for eeg_seq, eog_seq, bp, y in test_loader:
        eeg_seq = eeg_seq.to(device)
        eog_seq = eog_seq.to(device)
        bp = bp.to(device)

        outputs = model(eeg_seq, eog_seq, bp)
        preds = outputs.argmax(dim=1).cpu().numpy()

        all_preds.extend(preds)
        all_labels.extend(y.numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)

# ---------------- METRICS ---------------- #
acc = accuracy_score(all_labels, all_preds)

report = classification_report(
    all_labels,
    all_preds,
    target_names=STAGE_LABELS,
    output_dict=True
)

cm = confusion_matrix(all_labels, all_preds)

macro_f1 = np.mean([
    report[label]["f1-score"] for label in STAGE_LABELS
])
f1_scores = [report[label]["f1-score"] for label in STAGE_LABELS]
import matplotlib.pyplot as plt

plt.figure(figsize=(7, 4))
bars = plt.bar(STAGE_LABELS, f1_scores)
plt.ylim(0, 1)
plt.ylabel("F1-score")
plt.title("Per-class F1 Scores (Multimodal CNN-LSTM + Bandpower)")

# Annotate values
for bar, score in zip(bars, f1_scores):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        score + 0.02,
        f"{score:.2f}",
        ha="center",
        va="bottom"
    )

plt.tight_layout()
plt.savefig(f"{OUT_PREFIX}_f1_scores.png", dpi=300)
plt.close()

print(f" - {OUT_PREFIX}_f1_scores.png")

# ---------------- SAVE JSON METRICS ---------------- #
metrics = {
    "accuracy": acc,
    "macro_f1": macro_f1,
    "per_class": report,
    "confusion_matrix": cm.tolist()
}

with open(f"{OUT_PREFIX}_metrics.json", "w") as f:
    json.dump(metrics, f, indent=4)

# ---------------- PRINT SUMMARY ---------------- #
print("\n========== EVALUATION SUMMARY ==========")
print("Accuracy:", acc)
print("Macro F1:", macro_f1)
print(classification_report(all_labels, all_preds, target_names=STAGE_LABELS))

# ---------------- SAVE CONFUSION MATRIX FIGURE ---------------- #
plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=STAGE_LABELS,
    yticklabels=STAGE_LABELS
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Multimodal CNN-LSTM + Bandpower")

plt.tight_layout()
plt.savefig(f"{OUT_PREFIX}_confusion_matrix.png", dpi=300)
plt.close()

print("\nSaved:")
print(f" - {OUT_PREFIX}_metrics.json")
print(f" - {OUT_PREFIX}_confusion_matrix.png")
