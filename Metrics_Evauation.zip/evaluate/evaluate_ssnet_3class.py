import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import json
import matplotlib.pyplot as plt
import seaborn as sns
import os

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.ssnet_multimodal_3class import SSNetMultimodal3Class
from utils.label_utils import convert_to_3class


def main():
    # ================= CONFIG =================
    SEQ_LEN = 30
    BATCH_SIZE = 16
    NUM_CLASSES = 3
    LABELS = ["Wake", "NREM", "REM"]

    SAVE_DIR = "data/processed/EMG"
    CHECKPOINT = "best_ssnet_3class1.pth"
    OUT_DIR = "evaluation_outputs_3class"

    os.makedirs(OUT_DIR, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ================= LOAD TEST DATA =================
    X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
    X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
    X_emg = np.load(f"{SAVE_DIR}/X_emg_test.npy")
    y = convert_to_3class(np.load(f"{SAVE_DIR}/y_test.npy"))
    subjects = np.load(f"{SAVE_DIR}/subjects_test.npy")

    test_ds = MultimodalSequenceDataset(
        X_eeg, X_eog, X_emg,
        y, subjects, SEQ_LEN
    )

    test_loader = DataLoader(
        test_ds,
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    valid_indices = np.array(test_ds.valid_indices)
    y_true = y[valid_indices]

    # ================= LOAD MODEL =================
    model = SSNetMultimodal3Class().to(device)

    ckpt = torch.load("best_ssnet_3class1.pth", map_location=device)

    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)


    model.eval()
    print(f"✅ Loaded checkpoint: {CHECKPOINT}")

    # ================= INFERENCE =================
    y_pred = []

    with torch.no_grad():
        for eeg, eog, emg, _ in test_loader:
            eeg = eeg.to(device)
            eog = eog.to(device)
            emg = emg.to(device)

            preds = model(eeg, eog, emg).argmax(dim=1)
            y_pred.extend(preds.cpu().numpy())

    y_pred = np.array(y_pred)

    # ================= METRICS =================
    acc = accuracy_score(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred)
    report = classification_report(
        y_true, y_pred,
        target_names=LABELS,
        digits=4
    )

    print("\n📊 TEST RESULTS (3-CLASS)")
    print(f"Accuracy: {acc*100:.2f}%")
    print(report)

    # ================= SAVE JSON =================
    with open(f"{OUT_DIR}/metrics.json", "w") as f:
        json.dump(
            {
                "accuracy": acc,
                "confusion_matrix": cm.tolist(),
                "classification_report": report
            },
            f,
            indent=4
        )

    # ================= CONFUSION MATRIX PNG =================
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=LABELS,
        yticklabels=LABELS
    )
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title(f"3-Class Confusion Matrix (Acc = {acc*100:.2f}%)")
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/confusion_matrix.png", dpi=300)
    plt.close()

    print(f"\n📁 Results saved to: {OUT_DIR}")

    from utils.sleep_metrics import (
        estimate_sleep_duration,
        sleep_efficiency
    )

    y_pred = np.load("y_pred_test.npy")

    stats = estimate_sleep_duration(
        y_pred,
        sleep_labels=(1, 2)   # 3-class
    )

    eff = sleep_efficiency(y_pred)

    print("Sleep duration (hrs):", stats["sleep_hours"])
    print("Sleep efficiency (%):", eff)

if __name__ == "__main__":
    main()
