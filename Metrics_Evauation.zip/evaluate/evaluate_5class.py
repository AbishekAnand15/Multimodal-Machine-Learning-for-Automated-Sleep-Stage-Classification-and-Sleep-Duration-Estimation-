import os
import json
import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns

from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.ssnet_attn_5class import SSNetAttn5Class
# ================= CONFIG =================
SEQ_LEN = 20
BATCH_SIZE = 16
EPOCH_SEC = 30                     # Sleep-EDF epoch = 30 sec
MODEL_PATH = "best_5class_ssnet_attn.pth"

SAVE_DIR = "data/processed/EMG"
OUT_DIR = "evaluation_outputs_5class"

LABELS = ["Wake", "N1", "N2", "N3", "REM"]

os.makedirs(OUT_DIR, exist_ok=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ================= LOAD TEST DATA =================
X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
X_emg = np.load(f"{SAVE_DIR}/X_emg_test.npy")
y_test = np.load(f"{SAVE_DIR}/y_test.npy")
subjects = np.load(f"{SAVE_DIR}/subjects_test.npy")

test_ds = MultimodalSequenceDataset(
    X_eeg, X_eog, X_emg,
    y_test, subjects, SEQ_LEN
)

test_loader = DataLoader(
    test_ds, batch_size=BATCH_SIZE, shuffle=False
)

# Align labels with valid sequences
valid_idx = np.array(test_ds.valid_indices)
y_true = y_test[valid_idx]

# ================= LOAD MODEL =================
model = SSNetAttn5Class(num_classes=5).to(device)
ckpt = torch.load(MODEL_PATH, map_location=device)

if isinstance(ckpt, dict):
    if "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)   # raw state_dict saved as dict
else:
    model.load_state_dict(ckpt)


model.eval()

# ================= INFERENCE =================
y_pred = []

with torch.no_grad():
    for eeg, eog, emg, _ in test_loader:
        eeg = eeg.to(device)
        eog = eog.to(device)
        emg = emg.to(device)

        preds = model(eeg, eog, emg).argmax(dim=1)
        y_pred.extend(preds.cpu().numpy())

y_pred = np.array(y_pred)

# ================= METRICS =================
accuracy = accuracy_score(y_true, y_pred)
cm = confusion_matrix(y_true, y_pred)

report = classification_report(
    y_true,
    y_pred,
    labels=[0,1,2,3,4],
    target_names=LABELS,
    output_dict=True,
    zero_division=0
)

# ================= SLEEP DURATION METRICS =================
epoch_min = EPOCH_SEC / 60.0
total_epochs = len(y_pred)

wake_epochs = np.sum(y_pred == 0)
n1_epochs   = np.sum(y_pred == 1)
n2_epochs   = np.sum(y_pred == 2)
n3_epochs   = np.sum(y_pred == 3)
rem_epochs  = np.sum(y_pred == 4)

sleep_epochs = n1_epochs + n2_epochs + n3_epochs + rem_epochs

# Sleep latency (first non-Wake)
sleep_onset = np.where(y_pred != 0)[0]
sleep_latency_min = (
    sleep_onset[0] * epoch_min if len(sleep_onset) > 0 else None
)

# REM latency (first REM after sleep onset)
rem_idx = np.where(y_pred == 4)[0]
rem_latency_min = (
    (rem_idx[0] - sleep_onset[0]) * epoch_min
    if len(rem_idx) > 0 and len(sleep_onset) > 0 else None
)

sleep_metrics = {
    "total_recording_minutes": round(total_epochs * epoch_min, 2),
    "total_sleep_time_minutes": round(sleep_epochs * epoch_min, 2),
    "wake_time_minutes": round(wake_epochs * epoch_min, 2),
    "n1_time_minutes": round(n1_epochs * epoch_min, 2),
    "n2_time_minutes": round(n2_epochs * epoch_min, 2),
    "n3_time_minutes": round(n3_epochs * epoch_min, 2),
    "rem_time_minutes": round(rem_epochs * epoch_min, 2),
    "sleep_efficiency_percent": round((sleep_epochs / total_epochs) * 100, 2),
    "sleep_latency_minutes": None if sleep_latency_min is None else round(sleep_latency_min, 2),
    "rem_latency_minutes": None if rem_latency_min is None else round(rem_latency_min, 2)
}

# ================= SAVE JSON =================
with open(f"{OUT_DIR}/evaluation_metrics.json", "w") as f:
    json.dump(
        {
            "accuracy": round(accuracy, 4),
            "classification_report": report,
            "sleep_metrics": sleep_metrics
        },
        f,
        indent=4
    )

# ================= CONFUSION MATRIX PNG =================
plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=LABELS,
    yticklabels=LABELS
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title(f"5-Class Confusion Matrix (Acc = {accuracy*100:.2f}%)")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/confusion_matrix.png", dpi=300)
plt.close()

# ================= SUMMARY =================
print("\n📊 FINAL 5-CLASS EVALUATION")
print(f"Accuracy: {accuracy*100:.2f}%")
print("\n🛌 Sleep Estimation:")
for k, v in sleep_metrics.items():
    print(f"  {k}: {v}")

print(f"\n📁 Outputs saved in: {OUT_DIR}")
