import json
import numpy as np
import torch
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix, f1_score

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.multimodal_cnn_lstm_emg import MultimodalCNNLSTM_EMG_BP

# ---------------- CONFIG ---------------- #
SEQ_LEN = 20
BATCH_SIZE = 32
MODEL_PATH = "best_emg_model.pth"
SAVE_DIR = "data/processed/MULTI EMG"
OUT_JSON = "evaluation_cnn_lstm_emg.json"
OUT_F1_PNG = "f1_scores_cnn_lstm_emg.png"

CLASS_NAMES = ["W", "N1", "N2", "N3", "REM"]
# ---------------------------------------- #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD TEST DATA ---------------- #
X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
X_emg = np.load(f"{SAVE_DIR}/X_emg_test.npy")
bandpower = np.load(f"{SAVE_DIR}/bandpower_test.npy")
y = np.load(f"{SAVE_DIR}/y_test.npy")
subjects = np.load(f"{SAVE_DIR}/subjects_test.npy")

test_dataset = MultimodalSequenceDataset(
    X_eeg, X_eog, X_emg, bandpower, y, subjects, seq_len=SEQ_LEN
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ---------------- LOAD MODEL ---------------- #
model = MultimodalCNNLSTM_EMG_BP(
    num_classes=5,
    hidden_size=128
).to(device)

model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

# ---------------- EVALUATION ---------------- #
all_preds = []
all_labels = []
all_features = []

with torch.no_grad():
    for eeg, eog, emg, bp, yb in test_loader:
        eeg = eeg.to(device)
        eog = eog.to(device)
        emg = emg.to(device)
        bp = bp.to(device)

        outputs = model(eeg, eog, emg, bp)
        preds = outputs.argmax(dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(yb.numpy())

        # 🔑 feature extraction (penultimate layer)
        all_features.append(outputs.cpu().numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)
features = np.concatenate(all_features, axis=0)

# ---------------- METRICS ---------------- #
report = classification_report(
    all_labels,
    all_preds,
    target_names=CLASS_NAMES,
    output_dict=True
)

cm = confusion_matrix(all_labels, all_preds)

macro_f1 = f1_score(all_labels, all_preds, average="macro")
weighted_f1 = f1_score(all_labels, all_preds, average="weighted")
accuracy = (all_preds == all_labels).mean()

# ---------------- SAVE JSON ---------------- #
results = {
    "accuracy": float(accuracy),
    "macro_f1": float(macro_f1),
    "weighted_f1": float(weighted_f1),
    "classification_report": report,
    "confusion_matrix": cm.tolist()
}

with open(OUT_JSON, "w") as f:
    json.dump(results, f, indent=4)

print("✅ Evaluation JSON saved:", OUT_JSON)

# ---------------- F1 SCORE PLOT ---------------- #
f1_scores = [report[c]["f1-score"] for c in CLASS_NAMES]

plt.figure(figsize=(7, 5))
plt.bar(CLASS_NAMES, f1_scores)
plt.ylim(0, 1)
plt.ylabel("F1-score")
plt.title("Per-class F1 Scores (CNN-LSTM-EMG)")
plt.grid(axis="y")

plt.savefig(OUT_F1_PNG, dpi=300, bbox_inches="tight")
plt.close()

print("✅ F1 score plot saved:", OUT_F1_PNG)

# ---------------- PRINT SUMMARY ---------------- #
print("\n========== RESULTS ==========")
print("Accuracy:", accuracy)
print("Macro F1:", macro_f1)
print("Weighted F1:", weighted_f1)
print("\nClassification Report:")
print(classification_report(all_labels, all_preds, target_names=CLASS_NAMES))
