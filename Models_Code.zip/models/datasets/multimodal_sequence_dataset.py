import torch
from torch.utils.data import Dataset
import numpy as np


class MultimodalSequenceDataset(Dataset):
    """
    EEG + EOG → temporal
    EMG + Bandpower → last-epoch features
    """

    def __init__(self, X_eeg, X_eog, X_emg, bp, y, subjects, seq_len):
        self.X_eeg = X_eeg
        self.X_eog = X_eog
        self.X_emg = X_emg        # (N, 5)
        self.bp = bp              # (N, 5)
        self.y = y
        self.seq_len = seq_len

        self.valid_indices = []

        for i in range(len(y) - seq_len + 1):
            if len(set(subjects[i:i + seq_len])) == 1:
                self.valid_indices.append(i)

        print(f"[Dataset] Valid sequences: {len(self.valid_indices)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        i = self.valid_indices[idx]

        eeg = self.X_eeg[i:i+self.seq_len]
        eog = self.X_eog[i:i+self.seq_len]

        emg_feat = self.X_emg[i + self.seq_len - 1]
        bp_feat  = self.bp[i + self.seq_len - 1]
        label    = self.y[i + self.seq_len - 1]

        return (
            torch.from_numpy(eeg).float(),
            torch.from_numpy(eog).float(),
            torch.from_numpy(emg_feat).float(),
            torch.from_numpy(bp_feat).float(),
            torch.tensor(label, dtype=torch.long)
        )
