import torch
from torch.utils.data import Dataset

class SleepSequenceDataset(Dataset):
    def __init__(self, X, y, seq_len=5):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)
        self.seq_len = seq_len

    def __len__(self):
        return len(self.y) - self.seq_len + 1

    def __getitem__(self, idx):
        x_seq = self.X[idx:idx+self.seq_len]
        y_target = self.y[idx + self.seq_len // 2]
        return x_seq, y_target
