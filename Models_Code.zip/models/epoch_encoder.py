import torch
import torch.nn as nn
import torch.nn.functional as F

# -------------------------
# Epoch Encoder (CNN)
# -------------------------
class EpochEncoder(nn.Module):
    def __init__(self, out_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, 64, 7, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(64, 128, 7, padding=3),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(128, 256, 5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        self.fc = nn.Linear(256, out_dim)

    def forward(self, x):
        x = self.net(x).squeeze(-1)
        return self.fc(x)


# -------------------------
# Attention Pooling
# -------------------------
class AttentionPooling(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = nn.Linear(dim, 1)

    def forward(self, x):
        w = torch.softmax(self.attn(x), dim=1)
        return (w * x).sum(dim=1)


# -------------------------
# Hierarchical SleepNet
# -------------------------
class HierarchicalSleepNet(nn.Module):
    def __init__(self, num_classes=5):
        super().__init__()

        self.eeg = EpochEncoder(128)
        self.eog = EpochEncoder(128)
        self.emg = EpochEncoder(128)

        self.temporal = nn.LSTM(
            input_size=128 * 3,
            hidden_size=256,
            batch_first=True,
            bidirectional=True
        )

        self.pool = AttentionPooling(512)

        self.classifier = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)
        )

    def forward(self, eeg, eog, emg):
        B, T, _, _ = eeg.shape

        eeg = self.eeg(eeg.view(B*T, 1, -1))
        eog = self.eog(eog.view(B*T, 1, -1))
        emg = self.emg(emg.view(B*T, 1, -1))

        x = torch.cat([eeg, eog, emg], dim=1)
        x = x.view(B, T, -1)

        x, _ = self.temporal(x)
        x = self.pool(x)

        return self.classifier(x)
