import torch
import torch.nn as nn

# ---------- Epoch Encoder ----------
class EpochCNN(nn.Module):
    def __init__(self, out_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, 64, 7, padding=3),
            nn.GroupNorm(8, 64),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(64, 128, 7, padding=3),
            nn.GroupNorm(8, 128),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(128, 256, 5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        self.fc = nn.Linear(256, out_dim)

    def forward(self, x):
        return self.fc(self.net(x).squeeze(-1))


# ---------- Temporal Attention ----------
class TemporalAttention(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = nn.Linear(dim, 1)

    def forward(self, x):
        w = torch.softmax(self.attn(x.transpose(1, 2)), dim=1)
        return (x * w.transpose(1, 2)).sum(dim=2)


# ---------- SSNet + Attention ----------
class SSNetAttn5Class(nn.Module):
    def __init__(self, num_classes=5):
        super().__init__()

        self.eeg = EpochCNN(128)
        self.eog = EpochCNN(128)
        self.emg = EpochCNN(128)

        self.tcn = nn.Sequential(
            nn.Conv1d(384, 256, 3, padding=1),
            nn.ReLU(),
            nn.Conv1d(256, 256, 3, padding=2, dilation=2),
            nn.ReLU(),
            nn.Conv1d(256, 256, 3, padding=4, dilation=4),
            nn.ReLU()
        )

        self.attn = TemporalAttention(256)

        self.cls = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )

    def forward(self, eeg, eog, emg):
        B, T, _, _ = eeg.shape

        eeg = self.eeg(eeg.view(B*T, 1, -1))
        eog = self.eog(eog.view(B*T, 1, -1))
        emg = self.emg(emg.view(B*T, 1, -1))

        x = torch.cat([eeg, eog, emg], dim=1)
        x = x.view(B, T, -1).transpose(1, 2)

        x = self.tcn(x)
        x = self.attn(x)

        return self.cls(x)
