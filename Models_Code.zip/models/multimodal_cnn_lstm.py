import torch
import torch.nn as nn
import torch.nn.functional as F


class CNNEncoder(nn.Module):
    """
    CNN encoder for a single modality (EEG or EOG)
    Input: (B, 1, 3000)
    Output: (B, feature_dim)
    """
    def __init__(self):
        super().__init__()

        self.conv1 = nn.Conv1d(1, 32, kernel_size=7, padding=3)
        self.bn1 = nn.BatchNorm1d(32)

        self.conv2 = nn.Conv1d(32, 64, kernel_size=7, padding=3)
        self.bn2 = nn.BatchNorm1d(64)

        self.conv3 = nn.Conv1d(64, 128, kernel_size=7, padding=3)
        self.bn3 = nn.BatchNorm1d(128)

        self.pool = nn.MaxPool1d(2)

    def forward(self, x):
        # x: (B, 1, 3000)
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        x = self.pool(F.relu(self.bn3(self.conv3(x))))

        # Final length: 3000 / 2 / 2 / 2 = 375
        x = x.view(x.size(0), -1)  # (B, 128*375)
        return x


class MultimodalCNNLSTM(nn.Module):
    """
    Multimodal CNN-LSTM for EEG + EOG
    """
    def __init__(self, num_classes=5, hidden_size=128):
        super().__init__()

        # Separate encoders for each modality
        self.eeg_encoder = CNNEncoder()
        self.eog_encoder = CNNEncoder()

        # EEG + EOG feature dimension
        self.feature_dim = 2 * 128 * 375

        # Temporal modeling
        self.lstm = nn.LSTM(
            input_size=self.feature_dim,
            hidden_size=hidden_size,
            batch_first=True
        )

        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, eeg_seq, eog_seq):
        """
        eeg_seq: (B, T, 1, 3000)
        eog_seq: (B, T, 1, 3000)
        """
        B, T, _, _ = eeg_seq.shape

        # Merge batch and time for CNN
        eeg_seq = eeg_seq.view(B * T, 1, -1)
        eog_seq = eog_seq.view(B * T, 1, -1)

        eeg_feat = self.eeg_encoder(eeg_seq)
        eog_feat = self.eog_encoder(eog_seq)

        # Fuse modalities
        fused = torch.cat([eeg_feat, eog_feat], dim=1)

        # Restore sequence shape
        fused = fused.view(B, T, -1)

        lstm_out, _ = self.lstm(fused)

        # Use center epoch
        center_out = lstm_out[:, T // 2, :]

        return self.fc(center_out)
