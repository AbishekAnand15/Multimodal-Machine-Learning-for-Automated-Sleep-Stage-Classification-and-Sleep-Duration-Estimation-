import torch
import torch.nn as nn
import math

# ----------------------------
# Epoch CNN Encoder
# ----------------------------
class EpochCNN(nn.Module):
    def __init__(self, out_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, 64, 7, padding=3),
            nn.GroupNorm(8, 64),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(64, 128, 7, padding=3),
            nn.GroupNorm(8, 128),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(128, 256, 5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        self.fc = nn.Linear(256, out_dim)

    def forward(self, x):
        return self.fc(self.net(x).squeeze(-1))


# ----------------------------
# Positional Encoding
# ----------------------------
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=500):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len).unsqueeze(1)
        div = torch.exp(
            torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]


# ----------------------------
# Transformer SleepNet
# ----------------------------
class TransformerSleepNet(nn.Module):
    def __init__(self, num_classes=5):
        super().__init__()

        self.eeg = EpochCNN(128)
        self.eog = EpochCNN(128)
        self.emg = EpochCNN(128)

        self.pos = PositionalEncoding(384)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=384,
            nhead=8,
            dim_feedforward=1024,
            dropout=0.3,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=4
        )

        self.classifier = nn.Sequential(
            nn.Linear(384, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)
        )

    def forward(self, eeg, eog, emg):
        B, T, _, _ = eeg.shape

        eeg = self.eeg(eeg.view(B*T, 1, -1))
        eog = self.eog(eog.view(B*T, 1, -1))
        emg = self.emg(emg.view(B*T, 1, -1))

        x = torch.cat([eeg, eog, emg], dim=1).view(B, T, -1)
        x = self.pos(x)
        x = self.transformer(x)

        return self.classifier(x[:, -1])
