import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from models.multimodal_cnn_lstm_bp import MultimodalCNNLSTM_BP
from models.multimodal_cnn_transformer_emg import MultimodalCNNTransformer_EMG_BP
from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset

# ---------------- CONFIG ----------------
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

SEQ_LEN = 20
BATCH_SIZE = 16
NUM_CLASSES = 5

SAVE_DIR = "data/processed/MULTI EMG"

LSTM_MODEL_PATH = "multimodal_cnn_lstm_best.pth"
TRANS_MODEL_PATH = "best_emg_transformer_model.pth"

# Ensemble weights (can tune later)
W_LSTM = 0.5
W_TRANS = 0.5

# ---------------- LOAD TEST DATA ----------------
X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
X_emg = np.load(f"{SAVE_DIR}/X_emg_test.npy")
bp    = np.load(f"{SAVE_DIR}/bandpower_test.npy")
y     = np.load(f"{SAVE_DIR}/y_test.npy")
subjects = np.load(f"{SAVE_DIR}/subjects_test.npy")

test_dataset = MultimodalSequenceDataset(
    X_eeg, X_eog, X_emg, bp, y, subjects, seq_len=SEQ_LEN
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    pin_memory=True
)

# ---------------- LOAD MODELS ----------------
model_lstm = MultimodalCNNLSTM_BP(num_classes=NUM_CLASSES).to(DEVICE)
model_lstm.load_state_dict(torch.load(LSTM_MODEL_PATH, map_location=DEVICE))
model_lstm.eval()

model_trans = MultimodalCNNTransformer_EMG_BP(num_classes=NUM_CLASSES).to(DEVICE)
model_trans.load_state_dict(torch.load(TRANS_MODEL_PATH, map_location=DEVICE))
model_trans.eval()

# ---------------- ENSEMBLE INFERENCE ----------------
all_probs = []
all_labels = []

with torch.no_grad():
    for eeg, eog, emg, bp_batch, yb in test_loader:
        eeg = eeg.to(DEVICE)
        eog = eog.to(DEVICE)
        emg = emg.to(DEVICE)
        bp_batch = bp_batch.to(DEVICE)

        # ----- Model A: CNN + LSTM -----
        out_a = model_lstm(eeg, eog, bp_batch)
        prob_a = F.softmax(out_a, dim=1)

        # ----- Model B: CNN + Transformer -----
        out_b = model_trans(eeg, eog, emg, bp_batch)
        prob_b = F.softmax(out_b, dim=1)

        # ----- Weighted Ensemble -----
        probs = (W_LSTM * prob_a) + (W_TRANS * prob_b)

        all_probs.append(probs.cpu().numpy())
        all_labels.append(yb.numpy())

# ---------------- SAVE OUTPUTS ----------------
all_probs = np.concatenate(all_probs, axis=0)
all_labels = np.concatenate(all_labels, axis=0)

np.save("ensemble_probs.npy", all_probs)
np.save("ensemble_labels.npy", all_labels)

print("✅ Ensemble inference complete")
print("📁 Saved: ensemble_probs.npy, ensemble_labels.npy")
