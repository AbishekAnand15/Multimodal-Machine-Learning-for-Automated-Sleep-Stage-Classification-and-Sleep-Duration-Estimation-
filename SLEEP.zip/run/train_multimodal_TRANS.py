import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.ssnet_multimodal import SSNetMultimodalV2
from utils.label_utils import convert_to_3class


def main():
    # ================= CONFIG =================
    SEQ_LEN = 12            # 🔑 SHORTER for 3-class
    BATCH_SIZE = 16
    EPOCHS = 40
    LR = 3e-4
    # ==========================================

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    SAVE_DIR = "data/processed/EMG"

    # ================= LOAD DATA =================
    X_eeg_train = np.load(f"{SAVE_DIR}/X_eeg_train.npy")
    X_eog_train = np.load(f"{SAVE_DIR}/X_eog_train.npy")
    X_emg_train = np.load(f"{SAVE_DIR}/X_emg_train.npy")
    y_train = convert_to_3class(np.load(f"{SAVE_DIR}/y_train.npy"))
    subjects_train = np.load(f"{SAVE_DIR}/subjects.npy")[:len(y_train)]

    X_eeg_val = np.load(f"{SAVE_DIR}/X_eeg_val.npy")
    X_eog_val = np.load(f"{SAVE_DIR}/X_eog_val.npy")
    X_emg_val = np.load(f"{SAVE_DIR}/X_emg_val.npy")
    y_val = convert_to_3class(np.load(f"{SAVE_DIR}/y_val.npy"))
    subjects_val = np.load(f"{SAVE_DIR}/subjects.npy")[
        len(y_train):len(y_train) + len(y_val)
    ]

    # ================= DATASETS =================
    train_ds = MultimodalSequenceDataset(
        X_eeg_train, X_eog_train, X_emg_train,
        y_train, subjects_train, SEQ_LEN
    )

    val_ds = MultimodalSequenceDataset(
        X_eeg_val, X_eog_val, X_emg_val,
        y_val, subjects_val, SEQ_LEN
    )

    train_loader = DataLoader(
        train_ds, batch_size=BATCH_SIZE,
        shuffle=True, drop_last=True
    )

    val_loader = DataLoader(
        val_ds, batch_size=BATCH_SIZE,
        shuffle=False
    )

    # ================= MODEL =================
    model = SSNetMultimodalV2(num_classes=3).to(device)

    # 🔑 CLASS-WEIGHTED LOSS (CRITICAL)
    class_counts = np.bincount(y_train)
    class_weights = 1.0 / torch.tensor(class_counts, dtype=torch.float32)
    class_weights = class_weights / class_weights.sum()

    criterion = nn.CrossEntropyLoss(
        weight=class_weights.to(device),
        label_smoothing=0.05
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

    best_val_acc = 0.0

    # ================= TRAIN LOOP =================
    for epoch in range(EPOCHS):
        model.train()
        for eeg, eog, emg, yb in train_loader:
            eeg, eog, emg, yb = (
                eeg.to(device),
                eog.to(device),
                emg.to(device),
                yb.to(device)
            )

            optimizer.zero_grad()
            logits = model(eeg, eog, emg)
            loss = criterion(logits, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()

        # ---------- VALIDATION ----------
        model.eval()
        preds, labels = [], []

        with torch.no_grad():
            for eeg, eog, emg, yb in val_loader:
                eeg = eeg.to(device)
                eog = eog.to(device)
                emg = emg.to(device)

                p = model(eeg, eog, emg).argmax(dim=1)
                preds.extend(p.cpu().numpy())
                labels.extend(yb.numpy())

        val_acc = accuracy_score(labels, preds)
        print(f"Epoch {epoch+1}/{EPOCHS} | Val Accuracy: {val_acc*100:.2f}%")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "epoch": epoch,
                    "val_accuracy": best_val_acc
                },
                "best_emg_model_3classseq12.pth"
            )

    print("====================================")
    print(f"✅ Best Validation Accuracy: {best_val_acc*100:.2f}%")


if __name__ == "__main__":
    main()
