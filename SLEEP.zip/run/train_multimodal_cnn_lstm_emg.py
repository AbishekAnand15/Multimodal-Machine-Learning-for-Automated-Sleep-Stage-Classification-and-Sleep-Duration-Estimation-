import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.multimodal_cnn_transformer_emg import MultimodalCNNTransformer_EMG_BP

def main():
    print("🔥 Training started")

    # -------- CONFIG --------
    SEQ_LEN = 20
    BATCH_SIZE = 16
    EPOCHS = 30
    LR = 3e-4
    WEIGHT_DECAY = 1e-4

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # -------- LOAD DATA --------
    SAVE_DIR = "data/processed/MULTI EMG"

    X_eeg = np.load(f"{SAVE_DIR}/X_eeg.npy")
    X_eog = np.load(f"{SAVE_DIR}/X_eog.npy")
    X_emg = np.load(f"{SAVE_DIR}/X_emg.npy")
    bandpower = np.load(f"{SAVE_DIR}/bandpower.npy")
    y = np.load(f"{SAVE_DIR}/y.npy")
    subjects = np.load(f"{SAVE_DIR}/subjects.npy")

    # -------- SUBJECT SPLIT --------
    unique_subjects = np.unique(subjects)
    train_subj, temp_subj = train_test_split(unique_subjects, test_size=0.2, random_state=42)
    val_subj, _ = train_test_split(temp_subj, test_size=0.5, random_state=42)

    train_idx = np.isin(subjects, train_subj)
    val_idx = np.isin(subjects, val_subj)

    # -------- DATASETS --------
    train_dataset = MultimodalSequenceDataset(
        X_eeg[train_idx],
        X_eog[train_idx],
        X_emg[train_idx],
        bandpower[train_idx],
        y[train_idx],
        subjects[train_idx],
        seq_len=SEQ_LEN
    )

    val_dataset = MultimodalSequenceDataset(
        X_eeg[val_idx],
        X_eog[val_idx],
        X_emg[val_idx],
        bandpower[val_idx],
        y[val_idx],
        subjects[val_idx],
        seq_len=SEQ_LEN
    )

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # -------- MODEL --------
    model = MultimodalCNNTransformer_EMG_BP(num_classes=5, hidden_size=128).to(device)

    class_counts = np.bincount(y[train_idx])
    class_weights = torch.tensor(1.0 / class_counts, dtype=torch.float32).to(device)

    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)

    # -------- TRAIN LOOP --------
    best_val_acc = 0.0

    for epoch in range(EPOCHS):
        model.train()
        train_correct = train_total = 0

        for eeg, eog, emg, bp, yb in train_loader:
            eeg, eog, emg, bp, yb = (
                eeg.to(device),
                eog.to(device),
                emg.to(device),
                bp.to(device),
                yb.to(device)
            )

            optimizer.zero_grad()
            outputs = model(eeg, eog, emg, bp)
            loss = criterion(outputs, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()

            preds = outputs.argmax(dim=1)
            train_correct += (preds == yb).sum().item()
            train_total += yb.size(0)

        train_acc = train_correct / train_total

        model.eval()
        val_correct = val_total = 0
        with torch.no_grad():
            for eeg, eog, emg, bp, yb in val_loader:
                eeg, eog, emg, bp, yb = (
                    eeg.to(device),
                    eog.to(device),
                    emg.to(device),
                    bp.to(device),
                    yb.to(device)
                )
                preds = model(eeg, eog, emg, bp).argmax(dim=1)
                val_correct += (preds == yb).sum().item()
                val_total += yb.size(0)

        val_acc = val_correct / val_total

        print(f"Epoch [{epoch+1}/{EPOCHS}] | Train Acc: {train_acc:.4f} | Val Acc: {val_acc:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), "best_emg_transformer_model.pth")

    print("✅ Best validation accuracy:", best_val_acc)


if __name__ == "__main__":
    main()
