import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import json
import matplotlib.pyplot as plt
import seaborn as sns

from datasets.multimodal_sequence_dataset import MultimodalSleepSequenceDataset
from models.multimodal_cnn_lstm import MultimodalCNNLSTM
from utils.temporal_smoothing import smooth_predictions

# ---------------- CONFIG ---------------- #
SEQ_LEN = 10
BATCH_SIZE = 16
STAGE_LABELS = ["W", "N1", "N2", "N3", "REM"]
# ---------------------------------------- #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD TEST DATA ---------------- #
X_eeg_test = np.load("data/processed/MULTIMODAL/X_eeg_test.npy")
X_eog_test = np.load("data/processed/MULTIMODAL/X_eog_test.npy")
y_test = np.load("data/processed/MULTIMODAL/y_test.npy")
subjects_test = np.load("data/processed/MULTIMODAL/subjects_test.npy")

print("Loading test data...")
print("EEG:", X_eeg_test.shape)
print("EOG:", X_eog_test.shape)
print("y:", y_test.shape)
print("subjects:", subjects_test.shape)

# ---------------- DATASET ---------------- #
test_dataset = MultimodalSleepSequenceDataset(
    X_eeg_test,
    X_eog_test,
    y_test,
    subjects_test,
    seq_len=SEQ_LEN
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ---------------- LOAD MODEL ---------------- #
model = MultimodalCNNLSTM(num_classes=5, hidden_size=128).to(device)
model.load_state_dict(
    torch.load("multimodal_cnn_lstm_best.pth", map_location=device)
)
model.eval()

# ---------------- INFERENCE ---------------- #
all_preds, all_labels = [], []

with torch.no_grad():
    for (eeg_seq, eog_seq), y in test_loader:
        eeg_seq = eeg_seq.to(device)
        eog_seq = eog_seq.to(device)

        outputs = model(eeg_seq, eog_seq)
        preds = outputs.argmax(dim=1).cpu().numpy()

        all_preds.extend(preds)
        all_labels.extend(y.numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)


# ---------------- METRICS (RAW) ---------------- #
report_raw = classification_report(
    all_labels,
    all_preds,
    target_names=STAGE_LABELS,
    output_dict=True
)

cm_raw = confusion_matrix(all_labels, all_preds)


# ---------------- SAVE METRICS ---------------- #
with open("multimodal_report_raw.json", "w") as f:
    json.dump(report_raw, f, indent=4)



np.save("multimodal_cm_raw.npy", cm_raw)


# ---------------- PRINT RESULTS ---------------- #
print("\n========== BEFORE SMOOTHING ==========")
print("Accuracy:", accuracy_score(all_labels, all_preds))
print(classification_report(all_labels, all_preds, target_names=STAGE_LABELS))



macro_f1 = np.mean([report_raw[k]["f1-score"] for k in STAGE_LABELS])
print("\nMultimodal CNN-LSTM Macro F1:", macro_f1)

# ---------------- FIGURE 1: CONFUSION MATRIX ---------------- #
plt.figure(figsize=(7, 6))
sns.heatmap(
    cm_raw,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=STAGE_LABELS,
    yticklabels=STAGE_LABELS
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Multimodal CNN-LSTM Confusion Matrix")
plt.tight_layout()
plt.savefig("multimodal_confusion_matrix.png", dpi=300)
plt.close()

# ---------------- FIGURE 2: PER-CLASS F1 ---------------- #
f1_scores = [report_raw[k]["f1-score"] for k in STAGE_LABELS]

plt.figure(figsize=(7, 4))
plt.bar(STAGE_LABELS, f1_scores)
plt.ylim(0, 1)
plt.ylabel("F1-score")
plt.title("Multimodal CNN-LSTM Per-Class F1")

for i, v in enumerate(f1_scores):
    plt.text(i, v + 0.02, f"{v:.2f}", ha="center")

plt.tight_layout()
plt.savefig("multimodal_f1_scores.png", dpi=300)
plt.close()

print("\nMultimodal evaluation & figures saved.")
