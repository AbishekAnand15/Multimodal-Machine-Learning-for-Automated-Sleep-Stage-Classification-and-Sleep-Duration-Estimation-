import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix
import json
import matplotlib.pyplot as plt
import seaborn as sns

from datasets.sleep_sequence_dataset import SleepSequenceDataset
from models.cnn_lstm import SleepCNNLSTM

# ---------------- CONFIG ---------------- #
SEQ_LEN = 10  # must match training



BATCH_SIZE = 16
STAGE_LABELS = ["W", "N1", "N2", "N3", "REM"]
# ---------------------------------------- #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD TEST DATA ---------------- #
X_test = np.load("data/processed/X_test.npy")
y_test = np.load("data/processed/y_test.npy")

test_dataset = SleepSequenceDataset(X_test, y_test, seq_len=SEQ_LEN)
test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ---------------- LOAD MODEL ---------------- #
model = SleepCNNLSTM(num_classes=5, hidden_size=128).to(device)
model.load_state_dict(torch.load("cnn_lstm_best.pth", map_location=device))
model.eval()
subjects = np.load("data/processed/subjects_test.npy")

# ---------------- INFERENCE ---------------- #
all_preds, all_labels = [], []

with torch.no_grad():
    for x_seq, y in test_loader:
        x_seq = x_seq.to(device)
        outputs = model(x_seq)
        preds = outputs.argmax(dim=1).cpu().numpy()

        all_preds.extend(preds)
        all_labels.extend(y.numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)

# ---------------- METRICS ---------------- #
report = classification_report(
    all_labels,
    all_preds,
    target_names=STAGE_LABELS,
    output_dict=True
)

cm = confusion_matrix(all_labels, all_preds)

# ---------------- SAVE RAW METRICS ---------------- #
np.save("cnn_lstm_confusion_matrix.npy", cm)

with open("cnn_lstm_report.json", "w") as f:
    json.dump(report, f, indent=4)

macro_f1 = np.mean([report[k]["f1-score"] for k in STAGE_LABELS])
print("CNN-LSTM Macro F1:", macro_f1)

# ---------------- FIGURE 1: CONFUSION MATRIX ---------------- #
plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=STAGE_LABELS,
    yticklabels=STAGE_LABELS
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("CNN-LSTM Confusion Matrix")

plt.tight_layout()
plt.savefig("cnn_lstm_confusion_matrix.png", dpi=300)
plt.close()

# ---------------- FIGURE 2: PER-CLASS F1 ---------------- #
f1_scores = [report[k]["f1-score"] for k in STAGE_LABELS]

plt.figure(figsize=(7, 4))
plt.bar(STAGE_LABELS, f1_scores)
plt.ylim(0, 1)
plt.ylabel("F1-score")
plt.title("CNN-LSTM Per-Class F1 Scores")

for i, v in enumerate(f1_scores):
    plt.text(i, v + 0.02, f"{v:.2f}", ha="center")

plt.tight_layout()
plt.savefig("cnn_lstm_f1_scores.png", dpi=300)
plt.close()

print("CNN-LSTM evaluation & figures saved.")


