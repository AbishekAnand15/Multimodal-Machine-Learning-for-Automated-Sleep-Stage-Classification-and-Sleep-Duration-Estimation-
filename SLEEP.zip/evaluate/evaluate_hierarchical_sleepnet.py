import json
import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score
)
import matplotlib.pyplot as plt
import seaborn as sns
import os

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.epoch_encoder import HierarchicalSleepNetV2

# ======================================================
# CONFIG
# ======================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

SEQ_LEN = 20
BATCH_SIZE = 32
NUM_CLASSES = 5
LABELS = ["W", "N1", "N2", "N3", "REM"]

SAVE_DIR = "data/processed/EMG"
CHECKPOINT_PATH = "best_sleepedf_accuracy.pth"
OUT_DIR = "evaluation_outputs"

os.makedirs(OUT_DIR, exist_ok=True)

# ======================================================
# LOAD TEST DATA
# ======================================================
X_eeg = np.load(f"{SAVE_DIR}/X_eeg_test.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog_test.npy")
X_emg = np.load(f"{SAVE_DIR}/X_emg_test.npy")
y_all = np.load(f"{SAVE_DIR}/y_test.npy")
subjects_all = np.load(f"{SAVE_DIR}/subjects_test.npy")

test_dataset = MultimodalSequenceDataset(
    X_eeg,
    X_eog,
    X_emg,
    y_all,
    subjects_all,
    SEQ_LEN
)


test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=True
)

valid_indices = np.array(test_dataset.valid_indices)
y_true = y_all[valid_indices]

# ======================================================
# LOAD MODEL
# ======================================================
model = HierarchicalSleepNetV2(num_classes=NUM_CLASSES).to(DEVICE)
checkpoint = torch.load(CHECKPOINT_PATH, map_location=DEVICE)

if isinstance(checkpoint, dict) and "model_state" in checkpoint:
    model.load_state_dict(checkpoint["model_state"])
else:
    model.load_state_dict(checkpoint)

model.eval()
print(f"✅ Loaded checkpoint: {CHECKPOINT_PATH}")

# ======================================================
# INFERENCE
# ======================================================
y_pred = []

with torch.no_grad():
    for eeg, eog, emg, yb in test_loader:
        eeg = eeg.to(DEVICE)
        eog = eog.to(DEVICE)
        emg = emg.to(DEVICE)

        preds = model(eeg, eog, emg).argmax(dim=1)
        y_pred.extend(preds.cpu().numpy())

y_pred = np.array(y_pred)

# METRICS (ACCURACY FIRST)
# ======================================================
accuracy = accuracy_score(y_true, y_pred)
cm = confusion_matrix(y_true, y_pred)
report = classification_report(
    y_true,
    y_pred,
    target_names=LABELS,
    digits=4
)

# ======================================================
# SAVE METRICS JSON
# ======================================================
with open(f"{OUT_DIR}/metrics_accuracy.json", "w") as f:
    json.dump(
        {
            "accuracy": accuracy,
            "confusion_matrix": cm.tolist(),
            "classification_report": report
        },
        f,
        indent=4
    )

# ======================================================
# CONFUSION MATRIX PNG
# ======================================================
plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=LABELS,
    yticklabels=LABELS
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title(f"Confusion Matrix (Accuracy = {accuracy*100:.2f}%)")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/confusion_matrix_accuracy.png", dpi=300)
plt.close()

# ======================================================
# SUMMARY
# ======================================================
print("\n📊 Evaluation Complete")
print(f"✅ Test Accuracy : {accuracy*100:.2f}%")
print(f"📁 Outputs saved to: {OUT_DIR}")
