import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix

from datasets.sleep_dataset import SleepDataset
from models.cnn import SleepCNN

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# -------- LOAD DATA -------- #
X_test = np.load("data/processed/X_test.npy")
y_test = np.load("data/processed/y_test.npy")

test_dataset = SleepDataset(X_test, y_test)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

# -------- LOAD MODEL -------- #
model = SleepCNN(num_classes=5).to(device)
model.load_state_dict(torch.load("cnn_baseline_best.pth"))
model.eval()

# -------- EVALUATE -------- #
all_preds, all_labels = [], []

with torch.no_grad():
    for x, y in test_loader:
        x = x.to(device)
        outputs = model(x)
        preds = outputs.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(y.numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)

# -------- METRICS -------- #
report = classification_report(
    all_labels,
    all_preds,
    target_names=["W", "N1", "N2", "N3", "REM"],
    output_dict=True
)

cm = confusion_matrix(all_labels, all_preds)

# -------- SAVE -------- #
np.save("cnn_baseline_confusion_matrix.npy", cm)

import json
with open("cnn_baseline_report.json", "w") as f:
    json.dump(report, f, indent=4)

print("CNN baseline metrics saved.")
print("Macro F1:",
      np.mean([report[k]["f1-score"] for k in ["W","N1","N2","N3","REM"]]))
import matplotlib.pyplot as plt
import seaborn as sns

stage_labels = ["W", "N1", "N2", "N3", "REM"]

plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=stage_labels,
    yticklabels=stage_labels
)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("CNN Baseline Confusion Matrix")

plt.tight_layout()
plt.savefig("cnn_baseline_confusion_matrix.png", dpi=300)
plt.close()

f1_scores = [
    report["W"]["f1-score"],
    report["N1"]["f1-score"],
    report["N2"]["f1-score"],
    report["N3"]["f1-score"],
    report["REM"]["f1-score"],
]

plt.figure(figsize=(7, 4))
plt.bar(stage_labels, f1_scores)
plt.ylim(0, 1)
plt.ylabel("F1-score")
plt.title("CNN Baseline Per-Class F1 Scores")

for i, v in enumerate(f1_scores):
    plt.text(i, v + 0.02, f"{v:.2f}", ha="center")

plt.tight_layout()
plt.savefig("cnn_baseline_f1_scores.png", dpi=300)
plt.close()
