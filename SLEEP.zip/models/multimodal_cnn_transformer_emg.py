import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------- CNN ENCODER ---------------- #
class CNNEncoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, 32, 7, padding=3),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(32, 64, 7, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(64, 128, 7, padding=3),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )

    def forward(self, x):
        x = self.net(x)               # (B,128,375)
        return x.view(x.size(0), -1)  # (B,128*375)


# ---------------- TRANSFORMER MODEL ---------------- #
class MultimodalCNNTransformer_EMG_BP(nn.Module):
    def __init__(
        self,
        num_classes=5,
        hidden_size=256,
        nhead=8,
        num_layers=2,
        dropout=0.1
    ):
        super().__init__()

        # CNN encoders (temporal)
        self.eeg_enc = CNNEncoder()
        self.eog_enc = CNNEncoder()

        self.cnn_feat_dim = 2 * 128 * 375

        # Project CNN features → transformer dim
        self.proj = nn.Linear(self.cnn_feat_dim, hidden_size)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=nhead,
            dropout=dropout,
            batch_first=True
        )

        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_layers
        )

        # EMG FEATURES (5)
        self.emg_fc = nn.Sequential(
            nn.Linear(5, hidden_size),
            nn.ReLU()
        )

        # BANDPOWER (5)
        self.bp_fc = nn.Sequential(
            nn.Linear(5, hidden_size),
            nn.ReLU()
        )

        self.classifier = nn.Linear(hidden_size * 3, num_classes)

    def forward(self, eeg, eog, emg_feat, bp):
        """
        eeg: (B,T,1,3000)
        eog: (B,T,1,3000)
        emg_feat: (B,5)
        bp: (B,5)
        """

        B, T, _, _ = eeg.shape

        eeg = self.eeg_enc(eeg.view(B*T, 1, -1))
        eog = self.eog_enc(eog.view(B*T, 1, -1))

        fused = torch.cat([eeg, eog], dim=1)
        fused = fused.view(B, T, -1)

        x = self.proj(fused)
        x = self.transformer(x)
        x = x.mean(dim=1)  # temporal pooling

        emg = self.emg_fc(emg_feat)
        bp = self.bp_fc(bp)

        final = torch.cat([x, emg, bp], dim=1)
        return self.classifier(final)
