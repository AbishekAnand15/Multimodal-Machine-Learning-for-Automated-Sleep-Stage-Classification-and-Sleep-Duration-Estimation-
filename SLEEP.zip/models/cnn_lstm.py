import torch
import torch.nn as nn
import torch.nn.functional as F

class SleepCNNLSTM(nn.Module):
    def __init__(self, num_classes=5, hidden_size=128):
        super().__init__()

        # CNN encoder (same spirit as baseline)
        self.conv1 = nn.Conv1d(1, 32, 7, padding=3)
        self.bn1 = nn.BatchNorm1d(32)
        self.pool = nn.MaxPool1d(2)

        self.conv2 = nn.Conv1d(32, 64, 7, padding=3)
        self.bn2 = nn.BatchNorm1d(64)

        self.conv3 = nn.Conv1d(64, 128, 7, padding=3)
        self.bn3 = nn.BatchNorm1d(128)

        self.feature_dim = 128 * 375

        self.lstm = nn.LSTM(
            input_size=self.feature_dim,
            hidden_size=hidden_size,
            batch_first=True
        )

        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        # x: (B, T, 1, 3000)
        B, T, C, L = x.shape
        x = x.view(B*T, C, L)

        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        x = self.pool(F.relu(self.bn3(self.conv3(x))))

        x = x.view(B, T, -1)  # (B, T, feature_dim)

        lstm_out, _ = self.lstm(x)
        center_out = lstm_out[:, T//2, :]

        return self.fc(center_out)
