import torch
import torch.nn as nn

class EpochCNN(nn.Module):
    def __init__(self, out_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, 64, 7, padding=3),
            nn.GroupNorm(8, 64),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(64, 128, 7, padding=3),
            nn.GroupNorm(8, 128),
            nn.ReLU(),
            nn.MaxPool1d(2),

            nn.Conv1d(128, 256, 5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        self.fc = nn.Linear(256, out_dim)

    def forward(self, x):
        return self.fc(self.net(x).squeeze(-1))


class TemporalBlock(nn.Module):
    def __init__(self, in_ch, out_ch, dilation):
        super().__init__()
        self.conv = nn.Conv1d(
            in_ch, out_ch, 3,
            padding=dilation,
            dilation=dilation
        )
        self.norm = nn.GroupNorm(8, out_ch)
        self.relu = nn.ReLU()

    def forward(self, x):
        return self.relu(self.norm(self.conv(x)))


class SSNetMultimodal3Class(nn.Module):
    def __init__(self):
        super().__init__()

        self.eeg = EpochCNN(128)
        self.eog = EpochCNN(128)
        self.emg = EpochCNN(128)

        self.tcn = nn.Sequential(
            TemporalBlock(384, 256, 1),
            TemporalBlock(256, 256, 2),
            TemporalBlock(256, 256, 4)
        )

        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 3)
        )

    def forward(self, eeg, eog, emg):
        B, T, _, _ = eeg.shape

        eeg = self.eeg(eeg.view(B*T, 1, -1))
        eog = self.eog(eog.view(B*T, 1, -1))
        emg = self.emg(emg.view(B*T, 1, -1))

        x = torch.cat([eeg, eog, emg], dim=1)
        x = x.view(B, T, -1).transpose(1, 2)

        x = self.tcn(x)
        x = x[:, :, -1]   # last timestep

        return self.classifier(x)
