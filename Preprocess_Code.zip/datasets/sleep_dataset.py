import numpy as np
import torch
from torch.utils.data import Dataset


class SleepDataset(Dataset):
    """
    Sleep-EDF Dataset
    X shape: (N, C, T)
    y shape: (N,)
    """

    def __init__(self, X, y):
        assert len(X) == len(y), "X and y length mismatch"

        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]
