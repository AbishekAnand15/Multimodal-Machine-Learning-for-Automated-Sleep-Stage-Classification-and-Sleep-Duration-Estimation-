import torch
from torch.utils.data import Dataset
import numpy as np

class MultimodalSequenceDataset(Dataset):
    def __init__(self, X_eeg, X_eog, X_emg, y, subjects, seq_len):
        self.X_eeg = X_eeg
        self.X_eog = X_eog
        self.X_emg = X_emg
        self.y = y
        self.subjects = subjects
        self.seq_len = seq_len

        self.valid_indices = []
        for i in range(len(y) - seq_len + 1):
            if np.all(subjects[i:i+seq_len] == subjects[i]):
                self.valid_indices.append(i)

        print(f"[Dataset] Valid sequences: {len(self.valid_indices)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        i = self.valid_indices[idx]
        eeg = torch.tensor(self.X_eeg[i:i+self.seq_len], dtype=torch.float32)
        eog = torch.tensor(self.X_eog[i:i+self.seq_len], dtype=torch.float32)
        emg = torch.tensor(self.X_emg[i:i+self.seq_len], dtype=torch.float32)
        label = torch.tensor(self.y[i+self.seq_len-1], dtype=torch.long)
        return eeg, eog, emg, label
