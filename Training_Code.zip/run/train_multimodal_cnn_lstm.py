import numpy as np
import torch
from torch.utils.data import DataLoader

from datasets.multimodal_sequence_dataset import MultimodalSleepSequenceDataset
from models.multimodal_cnn_lstm_refined import MultimodalCNNLSTM

# ---------------- CONFIG ---------------- #
SEQ_LEN = 15
BATCH_SIZE = 16
EPOCHS = 30
LR = 1e-4

# ---------------------------------------- #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD DATA ---------------- #
X_eeg = np.load("data/processed/MULTIMODAL/X_eeg.npy")
X_eog = np.load("data/processed/MULTIMODAL/X_eog.npy")
y = np.load("data/processed/MULTIMODAL/y.npy")
subjects = np.load("data/processed/MULTIMODAL/subjects.npy")

# -------- SUBJECT-WISE SPLIT (reuse your logic) -------- #
from sklearn.model_selection import train_test_split

unique_subjects = np.unique(subjects)

train_subj, temp_subj = train_test_split(
    unique_subjects, test_size=0.2, random_state=42
)

val_subj, test_subj = train_test_split(
    temp_subj, test_size=0.5, random_state=42
)

train_idx = np.isin(subjects, train_subj)
val_idx   = np.isin(subjects, val_subj)
test_idx  = np.isin(subjects, test_subj)

# Save test split ONCE (important for evaluation later)
np.save("data/processed/MULTIMODAL/subjects_test.npy", subjects[test_idx])
np.save("data/processed/MULTIMODAL/X_eeg_test.npy", X_eeg[test_idx])
np.save("data/processed/MULTIMODAL/X_eog_test.npy", X_eog[test_idx])
np.save("data/processed/MULTIMODAL/y_test.npy", y[test_idx])

# ---------------- DATASETS ---------------- #
train_dataset = MultimodalSleepSequenceDataset(
    X_eeg[train_idx],
    X_eog[train_idx],
    y[train_idx],
    subjects[train_idx],
    seq_len=SEQ_LEN
)

val_dataset = MultimodalSleepSequenceDataset(
    X_eeg[val_idx],
    X_eog[val_idx],
    y[val_idx],
    subjects[val_idx],
    seq_len=SEQ_LEN
)

train_loader = DataLoader(
    train_dataset,
    batch_size=BATCH_SIZE,
    shuffle=True,
    drop_last=True
)

val_loader = DataLoader(
    val_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ---------------- CLASS WEIGHTS ---------------- #
class_counts = np.bincount(y[train_idx])
class_weights = 1.0 / class_counts
class_weights = class_weights / class_weights.sum()
class_weights = torch.tensor(class_weights, dtype=torch.float32).to(device)

# ---------------- MODEL ---------------- #
model = MultimodalCNNLSTM(num_classes=5, hidden_size=128).to(device)

criterion = torch.nn.CrossEntropyLoss(weight=class_weights)
optimizer = torch.optim.Adam(model.parameters(), lr=LR)

# ---------------- TRAIN LOOP ---------------- #
best_val_acc = 0.0

for epoch in range(EPOCHS):
    # ---- TRAIN ---- #
    model.train()
    train_correct, train_total = 0, 0

    for (eeg_seq, eog_seq), y_batch in train_loader:
        eeg_seq = eeg_seq.to(device)
        eog_seq = eog_seq.to(device)
        y_batch = y_batch.to(device)

        optimizer.zero_grad()
        outputs = model(eeg_seq, eog_seq)
        loss = criterion(outputs, y_batch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)

        optimizer.step()

        preds = outputs.argmax(dim=1)
        train_correct += (preds == y_batch).sum().item()
        train_total += y_batch.size(0)

    train_acc = train_correct / train_total

    # ---- VALIDATION ---- #
    model.eval()
    val_correct, val_total = 0, 0

    with torch.no_grad():
        for (eeg_seq, eog_seq), y_batch in val_loader:
            eeg_seq = eeg_seq.to(device)
            eog_seq = eog_seq.to(device)
            y_batch = y_batch.to(device)

            outputs = model(eeg_seq, eog_seq)
            preds = outputs.argmax(dim=1)

            val_correct += (preds == y_batch).sum().item()
            val_total += y_batch.size(0)

    val_acc = val_correct / val_total

    print(
        f"Epoch [{epoch+1}/{EPOCHS}] | "
        f"Train Acc: {train_acc:.4f} | "
        f"Val Acc: {val_acc:.4f}"
    )

    if val_acc > best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "multimodal_cnn_lstm_best.pth")

print("Best validation accuracy:", best_val_acc)
