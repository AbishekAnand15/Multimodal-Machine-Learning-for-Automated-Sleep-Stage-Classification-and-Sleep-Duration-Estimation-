import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score

from datasets.multimodal_sequence_dataset import MultimodalSequenceDataset
from models.ssnet_attn_3class import SSNetAttn3Class
from utils.label_utils import convert_to_3class

SEQ_LEN = 16
BATCH_SIZE = 16
EPOCHS = 30
LR = 3e-4

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SAVE_DIR = "data/processed/EMG"

X_eeg = np.load(f"{SAVE_DIR}/X_eeg.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog.npy")
X_emg = np.load(f"{SAVE_DIR}/X_emg.npy")
y = convert_to_3class(np.load(f"{SAVE_DIR}/y.npy"))
subjects = np.load(f"{SAVE_DIR}/subjects.npy")

subs = np.unique(subjects)
np.random.shuffle(subs)
train_sub = subs[:int(0.7*len(subs))]
val_sub   = subs[int(0.7*len(subs)):int(0.85*len(subs))]

train_idx = np.isin(subjects, train_sub)
val_idx   = np.isin(subjects, val_sub)

train_ds = MultimodalSequenceDataset(
    X_eeg[train_idx], X_eog[train_idx], X_emg[train_idx],
    y[train_idx], subjects[train_idx], SEQ_LEN
)
val_ds = MultimodalSequenceDataset(
    X_eeg[val_idx], X_eog[val_idx], X_emg[val_idx],
    y[val_idx], subjects[val_idx], SEQ_LEN
)

train_loader = DataLoader(train_ds, BATCH_SIZE, shuffle=True, drop_last=True)
val_loader   = DataLoader(val_ds, BATCH_SIZE, shuffle=False)

model = SSNetAttn3Class().to(device)
criterion = nn.CrossEntropyLoss(weight=torch.tensor([1.0, 1.0, 1.5], device=device))
optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

best_acc = 0.0

for epoch in range(EPOCHS):
    model.train()
    for eeg, eog, emg, yb in train_loader:
        eeg, eog, emg, yb = eeg.to(device), eog.to(device), emg.to(device), yb.to(device)
        optimizer.zero_grad()
        loss = criterion(model(eeg, eog, emg), yb)
        loss.backward()
        optimizer.step()

    model.eval()
    preds, labels = [], []
    with torch.no_grad():
        for eeg, eog, emg, yb in val_loader:
            p = model(eeg.to(device), eog.to(device), emg.to(device)).argmax(1)
            preds.extend(p.cpu().numpy())
            labels.extend(yb.numpy())

    acc = accuracy_score(labels, preds)
    print(f"Epoch {epoch+1}/{EPOCHS} | Val Acc: {acc*100:.2f}%")

    if acc > best_acc:
        best_acc = acc
        torch.save(model.state_dict(), "best_3class_clean.pth")

print(f"\n✅ BEST VAL ACC: {best_acc*100:.2f}%")
