import numpy as np
from sklearn.model_selection import train_test_split
import os

SAVE_DIR = "data/processed/MULTIMODAL"
os.makedirs(SAVE_DIR, exist_ok=True)

# ---------------- LOAD PROCESSED DATA ---------------- #
X_eeg = np.load(f"{SAVE_DIR}/X_eeg.npy")
X_eog = np.load(f"{SAVE_DIR}/X_eog.npy")
y = np.load(f"{SAVE_DIR}/y.npy")
subjects = np.load(f"{SAVE_DIR}/subjects.npy")

# ---------------- SUBJECT-WISE SPLIT ---------------- #
unique_subjects = np.unique(subjects)

train_subj, temp_subj = train_test_split(
    unique_subjects,
    test_size=0.2,
    random_state=42
)

val_subj, test_subj = train_test_split(
    temp_subj,
    test_size=0.5,
    random_state=42
)

train_idx = np.isin(subjects, train_subj)
val_idx   = np.isin(subjects, val_subj)
test_idx  = np.isin(subjects, test_subj)

# ---------------- SPLIT ALL MODALITIES ---------------- #
X_eeg_train, X_eeg_val, X_eeg_test = (
    X_eeg[train_idx], X_eeg[val_idx], X_eeg[test_idx]
)

X_eog_train, X_eog_val, X_eog_test = (
    X_eog[train_idx], X_eog[val_idx], X_eog[test_idx]
)

y_train, y_val, y_test = (
    y[train_idx], y[val_idx], y[test_idx]
)

subjects_train = subjects[train_idx]
subjects_val   = subjects[val_idx]
subjects_test  = subjects[test_idx]

# ---------------- SAVE SPLITS ---------------- #
np.save(f"{SAVE_DIR}/X_eeg_train.npy", X_eeg_train)
np.save(f"{SAVE_DIR}/X_eeg_val.npy",   X_eeg_val)
np.save(f"{SAVE_DIR}/X_eeg_test.npy",  X_eeg_test)

np.save(f"{SAVE_DIR}/X_eog_train.npy", X_eog_train)
np.save(f"{SAVE_DIR}/X_eog_val.npy",   X_eog_val)
np.save(f"{SAVE_DIR}/X_eog_test.npy",  X_eog_test)

np.save(f"{SAVE_DIR}/y_train.npy", y_train)
np.save(f"{SAVE_DIR}/y_val.npy",   y_val)
np.save(f"{SAVE_DIR}/y_test.npy",  y_test)

np.save(f"{SAVE_DIR}/subjects_train.npy", subjects_train)
np.save(f"{SAVE_DIR}/subjects_val.npy",   subjects_val)
np.save(f"{SAVE_DIR}/subjects_test.npy",  subjects_test)

# ---------------- SANITY CHECKS ---------------- #
print("Saved multimodal subject-wise splits")

print("Train EEG:", X_eeg_train.shape,
      "EOG:", X_eog_train.shape,
      "Subjects:", len(np.unique(subjects_train)))

print("Val   EEG:", X_eeg_val.shape,
      "EOG:", X_eog_val.shape,
      "Subjects:", len(np.unique(subjects_val)))

print("Test  EEG:", X_eeg_test.shape,
      "EOG:", X_eog_test.shape,
      "Subjects:", len(np.unique(subjects_test)))

print("Overlap train/val:", set(train_subj) & set(val_subj))
print("Overlap train/test:", set(train_subj) & set(test_subj))
