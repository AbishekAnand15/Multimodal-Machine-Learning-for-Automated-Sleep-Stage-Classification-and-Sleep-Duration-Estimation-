import numpy as np
from hmmlearn import hmm

# Load ensemble probabilities
probs = np.load("ensemble_probs.npy")
labels = np.load("ensemble_labels.npy")

NUM_CLASSES = 5

# ---- Transition matrix (physiology-aware) ----
transmat = np.array([
    [0.70, 0.25, 0.05, 0.00, 0.00],  # W
    [0.15, 0.50, 0.30, 0.05, 0.00],  # N1
    [0.05, 0.15, 0.60, 0.15, 0.05],  # N2
    [0.00, 0.05, 0.30, 0.60, 0.05],  # N3
    [0.20, 0.10, 0.20, 0.00, 0.50],  # REM
])

startprob = np.array([0.5, 0.2, 0.2, 0.05, 0.05])

model = hmm.CategoricalHMM(n_components=NUM_CLASSES)
model.startprob_ = startprob
model.transmat_ = transmat
model.emissionprob_ = np.eye(NUM_CLASSES)

# ---- Convert probs → observations ----
obs = np.argmax(probs, axis=1).reshape(-1, 1)

# ---- Viterbi decoding ----
smoothed_states = model.predict(obs)

np.save("final_predictions.npy", smoothed_states)

print("✅ HMM smoothing complete")
