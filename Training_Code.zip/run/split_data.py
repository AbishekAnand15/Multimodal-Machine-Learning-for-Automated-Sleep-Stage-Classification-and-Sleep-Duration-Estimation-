import numpy as np
from sklearn.model_selection import train_test_split
import os

# ================= CONFIG =================
SAVE_DIR = "data/processed/EMG"   # ← same dir used in training
os.makedirs(SAVE_DIR, exist_ok=True)
# =========================================

# ---------------- LOAD FULL DATA ----------------
X_eeg = np.load(f"{SAVE_DIR}/X_eeg.npy")      # (N, 1, 3000)
X_eog = np.load(f"{SAVE_DIR}/X_eog.npy")      # (N, 1, 3000)
X_emg = np.load(f"{SAVE_DIR}/X_emg.npy")      # (N, 1, 3000)  OR (N, 3000)
y     = np.load(f"{SAVE_DIR}/y.npy")
subjects = np.load(f"{SAVE_DIR}/subjects.npy")

print("Loaded:")
print("EEG:", X_eeg.shape)
print("EOG:", X_eog.shape)
print("EMG:", X_emg.shape)
print("Labels:", y.shape)

# ---------------- SUBJECT-WISE SPLIT ----------------
unique_subjects = np.unique(subjects)

train_subj, temp_subj = train_test_split(
    unique_subjects,
    test_size=0.2,
    random_state=42
)

val_subj, test_subj = train_test_split(
    temp_subj,
    test_size=0.5,
    random_state=42
)

train_idx = np.isin(subjects, train_subj)
val_idx   = np.isin(subjects, val_subj)
test_idx  = np.isin(subjects, test_subj)

# ---------------- SPLIT DATA ----------------
X_eeg_train, X_eeg_val, X_eeg_test = X_eeg[train_idx], X_eeg[val_idx], X_eeg[test_idx]
X_eog_train, X_eog_val, X_eog_test = X_eog[train_idx], X_eog[val_idx], X_eog[test_idx]
X_emg_train, X_emg_val, X_emg_test = X_emg[train_idx], X_emg[val_idx], X_emg[test_idx]

y_train, y_val, y_test = y[train_idx], y[val_idx], y[test_idx]
subjects_test = subjects[test_idx]

# ---------------- SAVE SPLITS ----------------
np.save(f"{SAVE_DIR}/X_eeg_train.npy", X_eeg_train)
np.save(f"{SAVE_DIR}/X_eeg_val.npy",   X_eeg_val)
np.save(f"{SAVE_DIR}/X_eeg_test.npy",  X_eeg_test)

np.save(f"{SAVE_DIR}/X_eog_train.npy", X_eog_train)
np.save(f"{SAVE_DIR}/X_eog_val.npy",   X_eog_val)
np.save(f"{SAVE_DIR}/X_eog_test.npy",  X_eog_test)

np.save(f"{SAVE_DIR}/X_emg_train.npy", X_emg_train)
np.save(f"{SAVE_DIR}/X_emg_val.npy",   X_emg_val)
np.save(f"{SAVE_DIR}/X_emg_test.npy",  X_emg_test)

np.save(f"{SAVE_DIR}/y_train.npy", y_train)
np.save(f"{SAVE_DIR}/y_val.npy",   y_val)
np.save(f"{SAVE_DIR}/y_test.npy",  y_test)

np.save(f"{SAVE_DIR}/subjects_test.npy", subjects_test)

# ---------------- SANITY CHECKS ----------------
print("\n✅ Saved hierarchical subject-wise splits\n")

print("Train EEG:", X_eeg_train.shape,
      "| Subjects:", len(np.unique(subjects[train_idx])))
print("Val   EEG:", X_eeg_val.shape,
      "| Subjects:", len(np.unique(subjects[val_idx])))
print("Test  EEG:", X_eeg_test.shape,
      "| Subjects:", len(np.unique(subjects[test_idx])))

print("\nLeakage check:")
print("Train ∩ Val:", set(train_subj) & set(val_subj))
print("Train ∩ Test:", set(train_subj) & set(test_subj))
print("Val ∩ Test:", set(val_subj) & set(test_subj))
