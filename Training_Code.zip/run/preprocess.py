from utils.preprocessing import run_preprocessing

run_preprocessing(
    raw_dir="data//raw\sleep-edf\sleep-cassette",
    save_dir="data/processed/MULTIMODAL"
)
