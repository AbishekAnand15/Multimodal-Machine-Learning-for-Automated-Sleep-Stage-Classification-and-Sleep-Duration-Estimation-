import numpy as np
import torch
from torch.utils.data import DataLoader
from datasets.sleep_dataset import SleepDataset
from models.cnn import SleepCNN

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------- LOAD DATA ---------------- #
X_train = np.load("data/processed/X_train.npy")
y_train = np.load("data/processed/y_train.npy")

X_val = np.load("data/processed/X_val.npy")
y_val = np.load("data/processed/y_val.npy")

train_dataset = SleepDataset(X_train, y_train)
val_dataset   = SleepDataset(X_val, y_val)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader   = DataLoader(val_dataset, batch_size=64, shuffle=False)

# ---------------- CLASS WEIGHTS ---------------- #
class_counts = np.bincount(y_train)
class_weights = 1.0 / class_counts
class_weights = class_weights / class_weights.sum()
class_weights = torch.tensor(class_weights, dtype=torch.float32).to(device)

# ---------------- MODEL ---------------- #
model = SleepCNN(num_classes=5).to(device)
criterion = torch.nn.CrossEntropyLoss(weight=class_weights)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# ---------------- TRAIN LOOP ---------------- #
EPOCHS = 20
best_val_acc = 0.0

for epoch in range(EPOCHS):
    # ---- TRAIN ---- #
    model.train()
    train_correct, train_total = 0, 0
    train_loss = 0

    for x, y in train_loader:
        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()
        outputs = model(x)
        loss = criterion(outputs, y)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        preds = outputs.argmax(dim=1)
        train_correct += (preds == y).sum().item()
        train_total += y.size(0)

    train_acc = train_correct / train_total

    # ---- VALIDATION ---- #
    model.eval()
    val_correct, val_total = 0, 0

    with torch.no_grad():
        for x, y in val_loader:
            x, y = x.to(device), y.to(device)
            outputs = model(x)
            preds = outputs.argmax(dim=1)
            val_correct += (preds == y).sum().item()
            val_total += y.size(0)

    val_acc = val_correct / val_total

    print(
        f"Epoch [{epoch+1}/{EPOCHS}] | "
        f"Train Acc: {train_acc:.4f} | "
        f"Val Acc: {val_acc:.4f}"
    )

    if val_acc > best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "cnn_baseline_best.pth")

print("Best validation accuracy:", best_val_acc)
